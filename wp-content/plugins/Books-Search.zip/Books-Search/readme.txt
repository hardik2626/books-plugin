=== Books Search ===
Contributors: Vision
Donate link: https://www.google.com/
License: GPLv3
License URI: https://www.google.com/
Tags: Books
Requires at least: 4.9
Tested up to: 5.2.4
Stable tag: 12.4
Requires PHP: 5.2.4

Book Searxh from User desk - Any End User can Search book from form using Publisher, Author name and Books name.

== Description ==

### Books: the #1 WordPress Books plugin